# Bricks Builder Reference

This folder does not contain guaranteed importable Bricks Builder exports. Bricks export structures depend on the installed Bricks version, site settings, element IDs, global classes, and component configuration.

Use these files as a build specification.

## Recommended build order

1. Add semantic colours and variables from `../acss-settings/`.
2. Create global classes from `class-map.csv`.
3. Build the core components listed in `component-blueprints.json`.
4. Convert repeated content into Bricks Components.
5. Create ACF field groups for services, locations, reviews, FAQs, and verified proof.
6. Build dynamic templates for service and location post types.
7. Add Polylang translations without duplicating the visual system.

## Avoid

- Importing unverified JSON into a production site.
- Random per-page classes.
- Deep element nesting.
- Fixed-height copy containers.
- Rebuilding identical sections separately for English and French.
