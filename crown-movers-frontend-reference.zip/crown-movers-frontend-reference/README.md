# Crown Movers / Déménagement Crown Frontend Reference

This is a frontend-focused reference package for Claude Design and the Crown Movers redesign.

## Official names

- English: **Crown Movers**
- French: **Déménagement Crown**

## Purpose

The package demonstrates a proposed design-system structure using plain HTML, CSS, and minimal JavaScript. It is intended to help Claude understand the visual language, component architecture, responsive behavior, bilingual requirements, and implementation constraints.

## Important

- The files in `bricks-exports/` are **implementation blueprints**, not guaranteed Bricks Builder import files.
- The files in `acss-settings/` are **mapping references**, not guaranteed Automatic CSS import files.
- Real photographs from `https://www.crownmovers.ca` may be used in design concepts and mockups.
- Do not hotlink existing-site images in the final production website. Copy approved originals into the new WordPress media library.
- Do not invent ratings, review counts, awards, statistics, pricing, certifications, service areas, or partnerships.

## Technology target

- WordPress
- Bricks Builder
- Automatic CSS
- Frames
- Advanced Custom Fields
- Polylang
- Rank Math

## Recommended reading order

1. `assets/brand/crown-movers-colour-palette.png`
2. `css/tokens.css`
3. `css/components.css`
4. `components/README.md`
5. `templates/home.html`
6. `bricks-exports/README.md`
7. `acss-settings/README.md`
