# Claude Design Instructions

Use this folder as the frontend and design-system reference for Crown Movers / Déménagement Crown.

Create one decisive bilingual visual system. Do not copy the current website layout. You may use any suitable photograph from `https://www.crownmovers.ca` in design concepts.

Priorities:

1. Calm operational confidence.
2. Authentic trucks, crews, equipment, and Montreal context.
3. Clear quote and phone conversion paths.
4. Accessible contrast and visible focus states.
5. French layouts that tolerate longer wording.
6. Reusable Bricks Builder components and ACF-driven templates.
7. Semantic Automatic CSS variables.
8. Minimal JavaScript.

Do not invent business claims. Mark unknown facts as placeholders or requiring confirmation.
