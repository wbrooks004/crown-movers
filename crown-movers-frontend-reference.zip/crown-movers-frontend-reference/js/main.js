import { initializeNavigation } from "./navigation.js";
import { initializeAccordions } from "./accordion.js";
import { initializeQuoteForms } from "./quote-form.js";

initializeNavigation();
initializeAccordions();
initializeQuoteForms();
