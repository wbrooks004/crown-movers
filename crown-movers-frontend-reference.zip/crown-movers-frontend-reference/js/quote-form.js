export function initializeQuoteForms() {
  document.querySelectorAll("[data-quote-form]").forEach((form) => {
    form.addEventListener("submit", (event) => {
      const requiredFields = [...form.querySelectorAll("[required]")];
      let firstInvalid = null;

      requiredFields.forEach((field) => {
        const invalid = !field.checkValidity();
        field.setAttribute("aria-invalid", String(invalid));
        if (invalid && !firstInvalid) firstInvalid = field;
      });

      if (firstInvalid) {
        event.preventDefault();
        firstInvalid.focus();
      }
    });
  });
}
