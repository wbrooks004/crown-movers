# Automatic CSS Mapping Reference

These files describe the intended semantic mapping. They are not guaranteed Automatic CSS import files.

## Recommended semantic assignments

- Primary: Crown Ink
- Action: Crown Coral
- Secondary: Crown Amber
- Base: Warm Base
- Surface: White
- Shade / body text: Body Gray
- Border: Border Gray
- Success: Crown Success
- Focus: Focus Blue

## Accessibility rule

Use Crown Ink text on Crown Coral and Crown Amber for normal-sized button labels. White text is not approved for normal-sized text on the principal brand colours.

## Suggested setup

1. Enter brand colours into Automatic CSS.
2. Map semantic variables to the values in `semantic-tokens.json`.
3. Recreate the spacing and type scales from `../css/tokens.css` where supported.
4. Use ACSS section, container, grid, flex, and spacing utilities where they match the design intent.
5. Add only the custom global classes ACSS does not already provide.
