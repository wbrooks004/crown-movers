# Existing Website Photography

Claude may use any suitable photograph currently published on:

https://www.crownmovers.ca

Prioritize authentic photographs showing:

- Crown Movers trucks
- Uniformed Crown Movers employees
- Wrapped or protected furniture
- Residential moves
- Commercial moves
- Packing and unpacking
- Stairs, elevators, loading areas, and realistic access conditions
- Montreal buildings, streets, apartments, and neighbourhood context

Use the accompanying `existing-site-photo-manifest.csv` as a starting list.

## Rules

- Prefer real Crown Movers photography over stock imagery.
- Do not create AI-generated replacement trucks, uniforms, logos, workers, or customers.
- Cropping and restrained colour correction are permitted for design concepts.
- Do not distort branding or fabricate situations.
- Mark low-resolution images as `higher-resolution original required`.
- Do not hotlink source-site imagery in production.
