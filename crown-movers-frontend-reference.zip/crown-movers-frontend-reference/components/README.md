# Component Reference

These files are plain HTML references for Claude and the implementation team. They are not WordPress templates and should be rebuilt as reusable Bricks components or Frames-compatible sections.

## Component principles

- Use semantic HTML.
- Use one coherent bilingual component system.
- Allow French content to expand without fixed heights.
- Map visual decisions to variables from `css/tokens.css`.
- Keep primary actions obvious: quote and phone.
- Use real Crown Movers photography where available.
- Keep JavaScript minimal and progressive.

## Suggested Bricks component names

- `cmp-header`
- `cmp-hero-split`
- `cmp-trust-strip`
- `cmp-service-card`
- `cmp-quote-panel`
- `cmp-faq-list`
- `cmp-footer`
- `cmp-mobile-actions`
