# Template References

These are static compositions that demonstrate how the components work together.

They are intentionally content-light and contain placeholders where facts must be verified. Claude should use them to infer layout, hierarchy, tokens, and component relationships rather than treat the copy as final.

Recommended dynamic WordPress template types:

- Homepage
- Service archive and single service
- Location archive and single location
- Quote page
- Blog archive and article
- Contact page
